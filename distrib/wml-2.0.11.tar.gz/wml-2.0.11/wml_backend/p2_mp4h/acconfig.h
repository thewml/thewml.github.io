
/* Name of the package */
#undef PACKAGE

/* Version number */
#undef VERSION

/* Define to 1 for better use of the debugging malloc library.  */
#undef WITH_DMALLOC

/* Define to 1 if there is support for dynamic loading of modules.  */
#undef WITH_MODULES

/* Default location for mp4h packages */
#undef PKGDATADIR

/* Default location for mp4h loadable modules */
#undef PKGLIBDIR

/* Define to 1 if the -ldl library should be used .  */
#undef HAVE_DLOPEN

/* Define to 1 if the -ldld library should be used .  */
#undef HAVE_SHL_LOAD
